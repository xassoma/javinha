/**
 * 
 */
/**
 * @author litllerat
 *
 */
module orientacaoAObjetosJavaGen {
}