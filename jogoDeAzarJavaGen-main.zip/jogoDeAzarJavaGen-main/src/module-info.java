/**
 * 
 */
/**
 * @author litllerat
 *
 */
module jogoDeAzarJava_Gen {
}