	/*
	 * Criar um "jogo de azar" onde:
	 * 
	 * a pessoa inicie com um saldo de 100 Montar um menu com 3 opções para o
	 * usuário, sendo elas: Ver o saldo atual Parar de jogar e ficar com o salto
	 * atual Continuar jogando
	 * 
	 * O jogo acaba quando: o usuário chegar a 200 de saldo (exibir mensagem de que
	 * ele ganhou) ficar com o saldo zerado (exibir mensagem de que ele perdeu)
	 * quando ele decidir parar (exibir mensagem agradecendo a participação e
	 * exibindo o saldo final)
	 * 
	 * Quando o usuário pedir para continuar jogando: - Rolar um "dado" que gere um
	 * numero aleatório entre 1 e 100 (não exibir para o usuário o resultado) - Caso
	 * o numero sorteado seja menor que 50, descontar o valor do saldo da pessoa -
	 * Caso seja maior que 50, adicionar metade do valor sorteado ao saldo do
	 * usuário - Caso a pessoa tire 50 no dado, não fazer nada
	 * 
	 * Ao final de cada rodada de dados, remontar o menu com as 3 opções, e deixar o
	 * usuário escolher o que prefere.
	 */# jogoDeAzarJavaGen
