package repeticaoJava;

public class ex003 {
    //3- Solicitar a idade de várias pessoas e imprimir: Total de pessoas com menos de
    //21 anos. Total de pessoas com mais de 50 anos. O programa termina quando
    //idade for =-99. (WHILE)
    public static void main(String[] args) {

    }
}
