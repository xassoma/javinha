package sobrecargaMetodos;

public class TesteSobrecarga {
    public static void main(String[] args) {
        Sobrecarga testeSalario = new Sobrecarga();

        testeSalario.testaMetodo();
    }
}
